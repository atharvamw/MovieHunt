﻿Imports System
Imports System.Windows.Forms

Public Class Form1
    Private tasks As New List(Of Task)

    Public Sub AddTask(ByVal t1 As Task)
        tasks.Add(t1)
    End Sub

    Public Sub ApplyTasks()

        tasks.Sort(Function(t1, t2) t2.Priority.CompareTo(t1.Priority))
        CheckBoxList.Items.Clear()
        For Each task As Task In tasks
            CheckBoxList.Items.Add(task.Name)
        Next
    End Sub

    Private Sub btnGetInput_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim InpForm As New txtInput()
        InpForm.Show()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim selectedIndices As New List(Of Integer)

        ' Find all selected items
        For i As Integer = 0 To CheckBoxList.Items.Count - 1
            If CheckBoxList.GetItemChecked(i) Then
                selectedIndices.Add(i)
            End If
        Next

        ' Remove the selected items in reverse order to avoid index shifting
        For i As Integer = selectedIndices.Count - 1 To 0 Step -1
            CheckBoxList.Items.RemoveAt(selectedIndices(i))
            tasks.RemoveAt(selectedIndices(i))
        Next
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

End Class

Public Class Task
    Public Name As String
    Public Description As String
    Public Priority As Integer

    Public Sub init(name As String, description As String, priority As Integer)
        Me.Name = name
        Me.Description = description
        Me.Priority = priority
    End Sub

End Class

