﻿Public Class txtInput
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim taskobj = New Task()
        taskobj.init(TBName.Text, TBDesc.Text, Val(TBPriority.Text))
        Form1.AddTask(taskobj)
        Form1.ApplyTasks()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class